# DieFits v2 - Industrial Fitting Inventory + Job Tracking

Business inventory app with job tracking and profit analysis.

## Features
- Email/password login (Supabase auth)
- Cloud-synced inventory with photo uploads
- Job tracking - record parts used per job
- Unit cost + bid tracking
- Reports: most-used parts, job margins, bid helper
- Low-stock email alerts

## Database Setup (run once in Supabase SQL Editor)
```sql
ALTER TABLE inventory ADD COLUMN IF NOT EXISTS photo TEXT DEFAULT '';
ALTER TABLE inventory ADD COLUMN IF NOT EXISTS unit_cost NUMERIC DEFAULT 0;

CREATE TABLE IF NOT EXISTS jobs (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  customer TEXT DEFAULT '',
  status TEXT DEFAULT 'active',
  start_date DATE DEFAULT CURRENT_DATE,
  end_date DATE,
  bid_amount NUMERIC DEFAULT 0,
  notes TEXT DEFAULT '',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS job_parts (
  id BIGSERIAL PRIMARY KEY,
  job_id BIGINT REFERENCES jobs(id) ON DELETE CASCADE,
  inventory_id BIGINT REFERENCES inventory(id) ON DELETE SET NULL,
  pn_snapshot TEXT,
  qty_used INTEGER NOT NULL DEFAULT 1,
  unit_cost_snapshot NUMERIC DEFAULT 0,
  notes TEXT DEFAULT '',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_parts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "auth users jobs" ON jobs FOR ALL
  USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "auth users job_parts" ON job_parts FOR ALL
  USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');
```

## Deploy
Push to GitHub - Vercel auto-deploys from main branch.
